# trading academy 

A Pen created on CodePen.io. Original URL: [https://codepen.io/AZIZ-ALMABOUDI/pen/XWvLOWB](https://codepen.io/AZIZ-ALMABOUDI/pen/XWvLOWB).

