const courses = {};
const articles = [];

// إضافة فيديو لدورة
function addVideo() {
  const courseTitle = document.getElementById("course-title").value.trim();
  const videoTitle = document.getElementById("video-title").value.trim();
  const videoLink = document.getElementById("video-link").value.trim();

  if (!courseTitle || !videoTitle || !videoLink) {
    alert("يرجى ملء جميع الحقول!");
    return;
  }

  if (!courses[courseTitle]) {
    courses[courseTitle] = [];
  }

  courses[courseTitle].push({ title: videoTitle, src: videoLink });

  // تحديث واجهة المستخدم
  updateCourseList();
  document.getElementById("course-title").value = "";
  document.getElementById("video-title").value = "";
  document.getElementById("video-link").value = "";
}

// تحديث قائمة الدورات
function updateCourseList() {
  const courseList = document.getElementById("course-list");
  courseList.innerHTML = "";

  for (const [courseTitle, videos] of Object.entries(courses)) {
    const courseDiv = document.createElement("div");
    courseDiv.className = "course-item";

    const courseHeader = document.createElement("h3");
    courseHeader.textContent = courseTitle;
    courseDiv.appendChild(courseHeader);

    const videoList = document.createElement("div");
    videoList.className = "video-list";

    videos.forEach(video => {
      const videoDiv = document.createElement("div");
      videoDiv.className = "video";
      videoDiv.innerHTML = `
        <h4>${video.title}</h4>
        <iframe src="${video.src}" allowfullscreen></iframe>
      `;
      videoList.appendChild(videoDiv);
    });

    courseDiv.appendChild(videoList);
    courseList.appendChild(courseDiv);
  }
}

// إضافة مقالة جديدة
function addArticle() {
  const articleTitle = document.getElementById("article-title").value.trim();
  const articleContent = document.getElementById("article-content").value.trim();

  if (!articleTitle || !articleContent) {
    alert("يرجى ملء جميع الحقول!");
    return;
  }

  articles.push({ title: articleTitle, content: articleContent });

  // تحديث واجهة المستخدم
  updateArticleList();
  document.getElementById("article-title").value = "";
  document.getElementById("article-content").value = "";
}

// تحديث قائمة المقالات
function updateArticleList() {
  const articleList = document.getElementById("article-list");
  articleList.innerHTML = "";

  articles.forEach(article => {
    const articleDiv = document.createElement("div");
    articleDiv.className = "article-item";

    articleDiv.innerHTML = `
      <h3>${article.title}</h3>
      <p>${article.content}</p>
    `;

    articleList.appendChild(articleDiv);
  });
}

// التبديل بين الوضع الليلي والنهاري
function toggleDarkMode() {
  document.body.classList.toggle("dark-mode");
}
